package e2098697;

/**
 *
 *
 */
public enum ZombieState {
    WANDERING,
    FOLLOWING;
}
