package e2098697;

/**
 *
 *
 */
public enum SoldierState {
    SEARCHING,
    AIMING,
    SHOOTING;
}
